 const mobileMenu = document.getElementById('mobile-menu');
 const navMenu = document.getElementById('nav-menu');
 
 mobileMenu.addEventListener('click', () => {
     navMenu.classList.toggle('active');
     mobileMenu.innerHTML = navMenu.classList.contains('active') ? 
         '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
 });
 
 document.querySelectorAll('#nav-menu a').forEach(link => {
     link.addEventListener('click', () => {
         navMenu.classList.remove('active');
         mobileMenu.innerHTML = '<i class="fas fa-bars"></i>';
     });
 });
 
 document.querySelectorAll('a[href^="#"]').forEach(anchor => {
     anchor.addEventListener('click', function(e) {
         e.preventDefault();
         
         const targetId = this.getAttribute('href');
         const targetElement = document.querySelector(targetId);
         
         if (targetElement) {
             window.scrollTo({
                 top: targetElement.offsetTop - 80,
                 behavior: 'smooth'
             });
         }
     });
 });
 
 const contactForm = document.getElementById('contactForm');
 
 contactForm.addEventListener('submit', function(e) {
     e.preventDefault();
     
     const formData = new FormData(this);
     const formValues = Object.fromEntries(formData.entries());
     
     console.log('Formulário enviado:', formValues);
     
     alert('Obrigado pela sua mensagem! Entraremos em contacto em breve.');
     this.reset();
 });
 
 const newsletterForm = document.getElementById('newsletterForm');
 
 newsletterForm.addEventListener('submit', function(e) {
     e.preventDefault();
     
     const email = this.querySelector('input[type="email"]').value;
     
     console.log('Email cadastrado na newsletter:', email);
     
     alert('Obrigado por assinar nossa newsletter!');
     this.reset();
 });
 window.addEventListener('scroll', function() {
     const scrollPosition = window.scrollY;
     
     if (scrollPosition > 100) {
         document.querySelector('header').classList.add('scrolled');
     } else {
         document.querySelector('header').classList.remove('scrolled');
     }
     
     animateOnScroll();
 });
 
 function animateOnScroll() {
     const sections = document.querySelectorAll('section');
     const windowHeight = window.innerHeight;
     
     sections.forEach(section => {
         const sectionTop = section.getBoundingClientRect().top;
         const sectionVisible = 150;
         
         if (sectionTop < windowHeight - sectionVisible) {
             section.classList.add('animated');
         }
     });
 }
 
 document.addEventListener('DOMContentLoaded', function() {
     animateOnScroll();
 });