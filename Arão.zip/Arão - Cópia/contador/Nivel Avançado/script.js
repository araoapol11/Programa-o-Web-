class Contador {
  constructor(container) {
    this.valor = 0;
    this.intervalo = null;
    this.historico = [];

    // Cria os elementos do DOM
    this.elemento = document.createElement("div");
    this.elemento.style.border = "1px solid #ccc";
    this.elemento.style.padding = "1rem";
    this.elemento.style.marginBottom = "1rem";
    this.elemento.style.borderRadius = "8px";

    this.valorEl = document.createElement("p");
    this.valorEl.textContent = `Valor: ${this.valor}`;
    this.valorEl.style.fontWeight = "bold";

    this.btnIniciar = document.createElement("button");
    this.btnIniciar.textContent = "Iniciar";
    this.btnIniciar.onclick = () => this.iniciar();

    this.btnParar = document.createElement("button");
    this.btnParar.textContent = "Parar";
    this.btnParar.onclick = () => this.parar();
    this.btnParar.style.marginLeft = "0.5rem";

    this.listaHistorico = document.createElement("ul");
    this.listaHistorico.style.marginTop = "1rem";

    // Junta tudo
    this.elemento.appendChild(this.valorEl);
    this.elemento.appendChild(this.btnIniciar);
    this.elemento.appendChild(this.btnParar);
    this.elemento.appendChild(this.listaHistorico);

    container.appendChild(this.elemento);
  }

  atualizarDisplay() {
    this.valorEl.textContent = `${this.valor}`;
  }

  registrarHistorico() {
    const li = document.createElement("li");
    li.textContent = `${this.valor}`;
    this.listaHistorico.appendChild(li);
  }

  iniciar() {
    if (this.intervalo) return; 
    this.intervalo = setInterval(() => {
      this.valor++;
      this.atualizarDisplay();
      this.registrarHistorico();
    }, 1000);
  }

  parar() {
    clearInterval(this.intervalo);
    this.intervalo = null;
  }
}

function adicionarContador() {
  const container = document.getElementById("contadores");
  new Contador(container);
}

// Cria o primeiro contador automaticamente
adicionarContador();