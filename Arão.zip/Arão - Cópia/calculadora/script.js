const calculator = {
  displayValue: '0',
  firstOperand: null,
  waitingForSecondOperand: false,
  operator: null,
  currentDisplayInput: '0',
};

function inputDigit(digit) {
  const { displayValue, waitingForSecondOperand, operator, firstOperand } = calculator;

  if (waitingForSecondOperand === true) {
    calculator.displayValue = digit;
    calculator.currentDisplayInput = `${firstOperand} ${operator} ${digit}`;
    calculator.waitingForSecondOperand = false;
  } else {
    calculator.displayValue = displayValue === '0' ? digit : displayValue + digit;
    if (operator && firstOperand !== null) {
      calculator.currentDisplayInput = `${firstOperand} ${operator} ${calculator.displayValue}`;
    } else {
      calculator.currentDisplayInput = calculator.displayValue;
    }
  }
}

function inputDecimal(dot) {
  const { displayValue, waitingForSecondOperand, operator, firstOperand } = calculator;

  if (waitingForSecondOperand === true) {
    calculator.displayValue = '0.';
    calculator.currentDisplayInput = `${firstOperand} ${operator} 0.`;
    calculator.waitingForSecondOperand = false;
    return;
  }

  if (!displayValue.includes(dot)) {
    calculator.displayValue += dot;
    if (operator && firstOperand !== null) {
      calculator.currentDisplayInput = `${firstOperand} ${operator} ${calculator.displayValue}`;
    } else {
      calculator.currentDisplayInput = calculator.displayValue;
    }
  }
}

function handleOperator(nextOperator) {
  const { firstOperand, displayValue, operator } = calculator;
  const inputValue = parseFloat(displayValue);

  if (operator && calculator.waitingForSecondOperand)  {
    calculator.operator = nextOperator;
    calculator.currentDisplayInput = `${firstOperand} ${nextOperator}`;
    return;
  }

  if (firstOperand === null && !isNaN(inputValue)) {
    calculator.firstOperand = inputValue;
    calculator.currentDisplayInput = `${inputValue} ${nextOperator}`;
  } else if (operator) {
    const result = operate(firstOperand, inputValue, operator);

    calculator.displayValue = String(result);
    calculator.firstOperand = result;

    if (nextOperator === '=') {
      calculator.currentDisplayInput = String(result);
    } else {
      calculator.currentDisplayInput = `${result} ${nextOperator}`;
    }
  }

  calculator.waitingForSecondOperand = true;
  calculator.operator = nextOperator;
}

function operate(firstOperand, secondOperand, operator) {
  if (operator === '+') {
    return firstOperand + secondOperand;
  } else if (operator === '-') {
    return firstOperand - secondOperand;
  } else if (operator === '*') {
    return firstOperand * secondOperand;
  } else if (operator === '/') {
    return firstOperand / secondOperand;
  }
  return secondOperand;
}

function resetCalculator() {
  calculator.displayValue = '0';
  calculator.firstOperand = null;
  calculator.waitingForSecondOperand = false;
  calculator.operator = null;
  calculator.currentDisplayInput = '0';
}

function updateDisplay() {
  const display = document.querySelector('.calculator-screen');
  display.value = calculator.currentDisplayInput;
}

updateDisplay();

const keys = document.querySelector('.calculator-keys');
keys.addEventListener('click', (event) => {
  const { target } = event;
  const { value } = target;

  if (!target.matches('button')) {
    return;
  }

  switch (value) {
    case '+':
    case '-':
    case '*':
    case '/':
    case '=':
      handleOperator(value);
      break;
    case '.':
      inputDecimal(value);
      break;
    case 'all-clear':
      resetCalculator();
      break;
    default:
      if (Number.isInteger(parseFloat(value))) {
        inputDigit(value);
      }
  }

  updateDisplay();
}); 